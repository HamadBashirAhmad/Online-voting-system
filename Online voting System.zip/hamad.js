let votes = {
    "Hamad Bashir": 0,
    "Ameer Hamza": 0,
    "Hanain Ahmad": 0
};

function submitVote() {
    const selectedOption = document.querySelector('input[name="vote"]:checked');
    if (selectedOption) {
        const optionValue = selectedOption.value;
        votes[optionValue]++;
        updateResults();
    } else {
        alert("Please select an option before submitting your vote.");
    }
}

function updateResults() {
    document.getElementById('resultOption1').textContent = "Hamad Bashir: " + votes["Hamad Bashir"] + " votes";
    document.getElementById('resultOption2').textContent = "Ameer Hamza: " + votes["Ameer Hamza"] + " votes";
    document.getElementById('resultOption3').textContent = "Hanain Ahmad: " + votes["Hanain Ahmad"] + " votes";
}
